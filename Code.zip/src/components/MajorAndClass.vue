<template>
    <div class="major">
        <div class="title">专业与班级</div>
        <div class="block">
            <el-cascader
                class="option"
                v-model="major_class"
                :options="majorData"
                :props="{ expandTrigger: 'hover' }"
                @change="handleChange"
            ></el-cascader>
        </div>
    </div>
</template>

<script>
export default {
    name: 'MajorAndClass',
    data () {
        return {
            major_class: [],
            "majorData": [{
                "value": "计算机科学与技术",
                "label": "计算机科学与技术",
                "children": [{
                    "value": "⼀班",
                    "label": "⼀班"
                },
                {
                    "value": "⼆班",
                    "label": "⼆班"
                },
                {
                    "value": "三班",
                    "label": "三班"
                },
                {
                    "value": "四班",
                    "label": "四班"
                }
                ]
            },
            {
                "value": "信息安全",
                "label": "信息安全",
                "children": [{
                    "value": "⼀班",
                    "label": "⼀班"
                },
                {
                    "value": "⼆班",
                    "label": "⼆班"
                },
                {
                    "value": "三班",
                    "label": "三班"
                },
                {
                    "value": "四班",
                    "label": "四班"
                }
                ]
            },
            {
                "value": "物联⽹",
                "label": "物联⽹",
                "children": [{
                    "value": "⼀班",
                    "label": "⼀班"
                },
                {
                    "value": "⼆班",
                    "label": "⼆班"
                }
                ]
            },
            {
                "value": "数据科学与⼤数据技术",
                "label": "数据科学与⼤数据技术",
                "children": [{
                    "value": "⼀班",
                    "label": "⼀班"
                },
                {
                    "value": "⼆班",
                    "label": "⼆班"
                }
                ]
            },
            {
                "value": "计算机科学与技术(中外合作)",
                "label": "计算机科学与技术(中外合作)",
                "children": [{
                    "value": "⼀班",
                    "label": "⼀班"
                },
                {
                    "value": "⼆班",
                    "label": "⼆班"
                },
                {
                    "value": "三班",
                    "label": "三班"
                },
                {
                    "value": "四班",
                    "label": "四班"
                },
                {
                    "value": "五班",
                    "label": "五班"
                },
                {
                    "value": "六班",
                    "label": "六班"
                }
                ]
            }
            ],

        }
    },
    methods: {
        handleChange (value) {
            console.log(value);
        }
    }
}
</script>

<style scoped>
.major {
    display: flex;
    flex-direction: column;
    align-items: center;
}
.title {
    font-size: 20px;
    color: rgb(247, 247, 247);
}
.option {
    width: 360px;
    margin: 10px;
}
</style>