<template>
    <div class="root">
        <div id="title">第二志愿</div>
        <div class="block">
            <el-cascader
                class="option"
                v-model="second_org_data"
                :options="orginazationData"
                :props="{ expandTrigger: 'hover' }"
                @change="handleChange"
            ></el-cascader>
        </div>
        <el-input
            type="textarea"
            :rows="5"
            placeholder="请输入加入此组织的理由"
            v-model="second_others"
            class="fst_oth"
        ></el-input>
    </div>
</template>

<script>
export default {
    name: "SecondVolunteer",
    data () {
        return {
            second_org_data: [],
            "orginazationData": [{
                "value": "科技协会",
                "label": "科技协会",
                "children": [{
                    "value": "科技协会",
                    "label": "科技协会"
                }]
            },
            {
                "value": "团委",
                "label": "团委",
                "children": [{
                    "value": "组织部",
                    "label": "组织部"
                },
                {
                    "value": "宣传部",
                    "label": "宣传部"
                },
                {
                    "value": "⼼协",
                    "label": "⼼协"
                },
                {
                    "value": "⻘协",
                    "label": "⻘协"
                }
                ]
            },
            {
                "value": "学⽣会",
                "label": "学⽣会",
                "children": [{
                    "value": "办公室",
                    "label": "办公室"
                },
                {
                    "value": "学习部",
                    "label": "学习部"
                },
                {
                    "value": "宣传部",
                    "label": "宣传部"
                },
                {
                    "value": "⽂艺部",
                    "label": "⽂艺部"
                },
                {
                    "value": "体育部",
                    "label": "体育部"
                },
                {
                    "value": "外联部",
                    "label": "外联部"
                },
                {
                    "value": "⾃管会",
                    "label": "⾃管会"
                }
                ]
            },
            {
                "value": "勤⼯助学中⼼",
                "label": "勤⼯助学中⼼",
                "children": [{
                    "value": "管理部",
                    "label": "管理部"
                },
                {
                    "value": "活动部",
                    "label": "活动部"
                },
                {
                    "value": "助贷部",
                    "label": "助贷部"
                },
                {
                    "value": "外联部",
                    "label": "外联部"
                }
                ]
            },
            {
                "value": "新闻中⼼",
                "label": "新闻中⼼",
                "children": [{
                    "value": "摄影协会",
                    "label": "摄影协会"
                },
                {
                    "value": "新媒体部",
                    "label": "新媒体部"
                },
                {
                    "value": "记者团",
                    "label": "记者团"
                }
                ]
            }
            ],
            second_others: '',
        }
    },
    methods: {
        handleChange (value) {
            console.log(value);
        }
    },
}
</script>

<style scoped>
#title {
    font-size: 20px;
    color: rgb(247, 247, 247);
}
.root {
    display: flex;
    flex-direction: column;
    align-items: center;
}
.block {
    margin: 10px;
}
.option {
    width: 360px;
}
.fst_oth {
    width: 360px;
}
</style>