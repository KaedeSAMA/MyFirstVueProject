<template>
    <div>
        <SelfInformation />
        <MajorAndClass />
        <FirstVolunteer />
        <SecondVolunteer />
        <WhetherAdjustment />
    </div>
</template>

<script>
import SelfInformation from "../components/SelfInformation.vue"
import MajorAndClass from '../components/MajorAndClass.vue'
import FirstVolunteer from '../components/FirstVolunteer.vue'
import SecondVolunteer from '../components/SecondVolunteer.vue'
import WhetherAdjustment from '../components/WhetherAdjustment.vue'
export default {
    name: "Form",
    components: {
        SelfInformation,
        MajorAndClass,
        FirstVolunteer,
        SecondVolunteer,
        WhetherAdjustment,
    },
    data () {
        return {

        }
    },

};

</script>

<style>
</style>