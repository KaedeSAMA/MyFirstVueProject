<template>
    <div class="rain">
        <div
            v-for="(item,index) in rainNumber"
            :key="index"
            class="rain-item"
            ref="rain-item"
            :style="`transform:rotate(${rotateDeg}deg);width:${w}px;height:${h}px;`"
        >
            <div class="line" :style="`animationDelay:${index*100}ms`"></div>
        </div>
    </div>
</template>

<script>
export default {
    name: "Rain",
    data () {
        return {
            scr_wid: document.documentElement.clientWidth,
            scr_hig: document.documentElement.clientHeight,
        }
    },
    props: {
        rainNumber: {
            type: Number,
            default: 0,
        },
        rotateDeg: {
            type: Number,
            default: 0,
        },
        w: {
            type: Number,
            default: 0,
        },
        h: {
            type: Number,
            default: 0,
        },
    },
    mounted () {
        this.randomRain();
        this.scr_wid = document.body.clientWidth;
        this.scr_hig = document.body.clientHeight;
        setTimeout(() => {
            window.onresize = () => {
                return (() => {
                    this.scr_wid = document.body.clientWidth;
                    this.scr_hig = document.body.clientHeight;
                    console.log('下雨的宽度变了');
                })();
            };
        }, 300);
    },
    methods: {
        randomRain () {
            let rainArr = this.$refs["rain-item"];
            // console.log(rainArr);
            rainArr.forEach((item) => {
                // console.log(item.children);
                item.style.top = Math.floor(Math.random() * this.scr_hig * 0.5 + 1) + "px";
                item.style.left = Math.floor(Math.random() * this.scr_wid * 0.95 + 1) + "px";
            });
        },
    },
    watch: {
        scr_wid (val) {
            console.log(val, 'rain');
            this.randomRain();
        },
        scr_hig (val) {
            console.log(val);
            this.randomRain();
        }
    }
};
</script>

<style lang='less' scoped>
.rain {
    width: 100%;
    height: 100%;
    position: relative;
    .rain-item {
        position: absolute;
        width: 2px;
        height: 30px;
        // background: skyblue;
        display: inline-block;
        // overflow: hidden;
        .line {
            animation: raining 2s infinite linear;
            position: absolute;
            content: "";
            top: -30px;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 183, 255, 0.7);
        }
    }
}
@keyframes raining {
    0% {
        top: -30px;
        opacity: 0;
    }
    50% {
        top: 0px;
        opacity: 1;
    }
    100% {
        top: 30px;
        opacity: 0;
    }
}
</style>
