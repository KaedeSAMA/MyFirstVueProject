<template>
    <div class="star">
        <div
            v-for="(item,index) in starNumber"
            :key="index"
            class="star-item"
            ref="star-item"
            :style="`animationDelay:${index*100}ms;width:${w}px;height:${h}px;`"
        ></div>
    </div>
</template>

<script>
export default {
    name: "Star",
    data () {
        return {
            scr_wid: document.documentElement.clientWidth,
            scr_hig: document.documentElement.clientHeight,
        }
    },
    props: {
        starNumber: {
            type: Number,
            default: 0,
        },
        w: {
            type: Number,
            default: 0,
        },
        h: {
            type: Number,
            default: 0,
        },
    },
    mounted () {
        this.randomStar();
        this.scr_wid = document.body.clientWidth;
        this.scr_hig = document.body.clientHeight;
        setTimeout(() => {
            window.onresize = () => {
                return (() => {
                    this.scr_wid = document.body.clientWidth;
                    this.scr_hig = document.body.clientHeight;
                    console.log('星星的宽度变了');
                })();
            };
        }, 100);
    },
    methods: {
        randomStar () {
            let starArr = this.$refs["star-item"];
            // console.log(starArr);
            starArr.forEach((item) => {
                // console.log(item.children);
                item.style.top = Math.floor(Math.random() * this.scr_hig * 0.4 + 1) + "px";
                item.style.left = Math.floor(Math.random() * this.scr_wid + 1) + "px";
            });
        },
    },
    watch: {
        scr_wid (val) {
            console.log(val, 'star');
            this.randomStar();
        },
        scr_hig (val) {
            console.log(val);
            this.randomStar();
        }
    }
};
</script>

<style lang='less' scoped>
.star {
    position: relative;
    .star-item {
        position: absolute;
        width: 4px;
        height: 4px;
        display: inline-block;
        animation: staring 2s infinite linear;
        background: rgba(2, 213, 255, 1);
        border-radius: 50%;
    }
}
@keyframes staring {
    0% {
        opacity: 0;
    }
    50% {
        opacity: 1;
    }
    100% {
        opacity: 0;
    }
}
</style>
