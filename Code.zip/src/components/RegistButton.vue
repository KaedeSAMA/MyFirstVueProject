<template>
    <div class="root">
        <el-button class="reg_btn" type="success" round>报名</el-button>
    </div>
</template>

<script>
export default {
    name: "RegistButton"
}
</script>

<style scoped>
.root {
    display: flex;
    flex-direction: column;
    align-items: center;
}
.reg_btn {
    margin: 10px;
    width: 360px;
}
</style>