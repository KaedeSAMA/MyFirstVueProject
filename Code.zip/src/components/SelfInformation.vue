<template>
    <div id="self_inf">
        <div id="title">个人信息</div>
        <el-input
            class="ipt"
            placeholder="学号"
            suffix-icon="el-icon-bank-card"
            v-model="self_student_id"
        ></el-input>
        <el-input
            class="ipt"
            placeholder="姓名"
            suffix-icon="el-icon-user"
            v-model="self_student_name"
        ></el-input>
        <el-input
            class="ipt"
            placeholder="QQ"
            suffix-icon="el-icon-s-opportunity"
            v-model="self_student_qq"
        ></el-input>
        <el-input
            class="ipt"
            placeholder="手机"
            suffix-icon="el-icon-phone-outline"
            v-model="self_student_phone"
        ></el-input>
    </div>
</template>

<script>
export default {
    name: 'SelfInformation',
    data () {
        return {
            self_student_id: "",
            self_student_name: "",
            self_student_qq: "",
            self_student_phone: "",
        }
    },
}
</script>

<style scoped>
#title {
    font-size: 20px;
    color: rgb(247, 247, 247);
}
#self_inf {
    display: flex;
    flex-direction: column;
    align-items: center;
}
.ipt {
    width: 360px;
    margin: 10px;
}
</style>