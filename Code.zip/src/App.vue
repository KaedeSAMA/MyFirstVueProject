<template>
    <div id="app">
        <Star :starNumber="25" :w="4" :h="4" class="star0"></Star>

        <Rain :rainNumber="50" :rotateDeg="-25" :w="1" :h="35"></Rain>
        <StarMove :delay="0" :w="2" :h="300" :rotateDeg="-60" class="star_move0"></StarMove>
        <StarMove :delay="30" :w="2" :h="250" :rotateDeg="-70" class="star_move1"></StarMove>
        <StarMove :delay="2" :w="2" :h="250" :rotateDeg="-60" class="star_move"></StarMove>
        <StarMove :delay="6" :w="2" :h="250" :rotateDeg="-60" class="star_move"></StarMove>
        <InnerApp class="inner_app" />
    </div>
</template>

<script>
import InnerApp from './components/InnerApp.vue'
import StarMove from './components/StarMove.vue'
import Rain from './components/Rain.vue'
import Star from './components/Star.vue'

export default {
    name: 'App',
    components: {
        InnerApp,
        StarMove,
        Rain,
        Star,
    },
}

</script>

<style>
#app {
    display: flex;
    flex-direction: column;
    align-items: center;
}
.inner_app {
    position: absolute;
    top: 20px;
    z-index: 1;
}

.star_move0 {
    position: absolute !important;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
}
.star_move1 {
    position: absolute !important;
    top: 6%;
    left: 25%;
    right: 0;
    bottom: 0;
}
.star0 {
    position: absolute !important;
    top: 0;
    left: 0;
}

body {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    background: radial-gradient(
        200% 100% at bottom center,
        #f7f7b6,
        #e96f92,
        #1b2947
    );
    background: radial-gradient(
        200% 105% at top center,
        #1b2947 10%,
        #75517d 40%,
        #e96f92 65%,
        #f7f7b6
    );
    background-attachment: fixed;
}
</style>
