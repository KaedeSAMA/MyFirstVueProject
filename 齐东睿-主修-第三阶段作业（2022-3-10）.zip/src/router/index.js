import Vue from 'vue'
import Router from 'vue-router'
import FormSubmitApp from '../components/FormSubmit/FormSubmitApp.vue';

Vue.use(Router)
const router = new Router({
    routes: [
        {
            path: '/',
            redirect: '/FormSubmitApp'
        },
        {
            path: '/login',
            name: 'LogIn',
            component: () => import('../components/Login/LogIn.vue')
        },
        {
            path: '/backgroundmanage',
            name: 'BackgroundManageApp',
            component: () => import('../components/BackgroundManage/BackgroundManageApp.vue')
        },
        {
            path: '/FormSubmitApp',
            name: 'FormSubmitApp',
            component: FormSubmitApp
        }

    ]
})

//路由守卫

// router.beforeEach((to, from, next) => {
//     // 通常用于常见的登录权限验证
//     console.log(to, from);
//     next();
// });


export default router
