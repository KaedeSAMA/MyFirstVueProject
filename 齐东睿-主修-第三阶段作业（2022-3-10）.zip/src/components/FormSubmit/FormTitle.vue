<template>
    <div id="header_title">
        <h1 class="title">天津理工大学计算机科学与工程学院</h1>
        <h1 class="title">学生组织报名系统</h1>
    </div>
</template>

<script>
export default {
    name: "FormTitle"
}
</script>

<style scoped>
#header_title {
    display: flex;
    flex-direction: column;
    align-items: center;
}
.title {
    margin: 10px;
    color: rgb(255, 255, 255);
}
</style>