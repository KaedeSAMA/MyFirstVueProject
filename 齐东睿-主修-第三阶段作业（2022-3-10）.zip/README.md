# final_test

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

######
已知缺点：

1.组件复用程度还不够高
2.防抖函数暂未添加
3.后台编辑界面需要打开两次编辑才能出现编辑的默认信息（挂载钩子解决无效，正在尝试进一步解决方案）
