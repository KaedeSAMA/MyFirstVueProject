<template>
    <div>这里是其他提示</div>
</template>

<script>
export default {
    name: "OtherTips"
}
</script>

<style scoped>
</style>