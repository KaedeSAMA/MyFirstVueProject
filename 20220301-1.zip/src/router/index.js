import Vue from 'vue'
import Router from 'vue-router'


Vue.use(Router)
const router = new Router({
    routes: [
        {
            path: '/login',
            name: 'LogIn',
            component: () => import('../components/Login/LogIn.vue')
        },
        {
            path: '/backgroundmanage',
            name: 'BackgroundManageApp',
            component: () => import('../components/BackgroundManage/BackgroundManageApp.vue')
        },
        {
            path: '/FormSubmitApp',
            name: 'FormSubmitApp',
            component: () => import('../components/FormSubmit/FormSubmitApp.vue')
        }

    ]
})
export default router
