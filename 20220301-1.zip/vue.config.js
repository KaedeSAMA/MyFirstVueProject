module.exports = {
    //关闭语法检测
    lintOnSave: false
}